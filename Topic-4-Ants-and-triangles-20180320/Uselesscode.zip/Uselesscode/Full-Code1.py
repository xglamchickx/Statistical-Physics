import math
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import numpy as np
import random
import operator

p1 = (0, 0)
p2 = (3, 0)
p3 = (0, 4)

def points(p1, p2, p3):
    q, p = sorted([random.random(), random.random()])
    return (q * p1[0] + (p-q) * p2[0] + (1-p) * p3[0], q * p1[1] + (p-q) * p2[1] + (1-p) * p3[1])

def getdata(file):
    with open(file, 'r') as data:
        content = data.readlines()
        content = [x.strip() for x in content]

        datalist = []
        x1 = []
        for index in range(0, len(content)):
            test = [int(x) for x in content[index].split(' ')]
            datalist.append(test)
            x1.append(test[2])
        datalist = tuple([datalist])

        
        return datalist, x1


def points(p1, p2, p3):
    #refers to the coordiantes of three vertexs in the right triangle
    q, p = sorted([random.random(), random.random()])
    return (q * p1[0] + (p-q) * p2[0] + (1-p) * p3[0], q * p1[1] + (p-q) * p2[1] + (1-p) * p3[1])

def ag(x, y, a, b):
    return math.acos((x*(x-a) + y*(y-b))/(((x**2 + (y-b)**2)**(1./2.))*((x-a)**2 + y**2)**(1./2.)))



#----------

file = 'triangle_triples.data' 
#M , x = getdata(file)


point = [points(p1, p2, p3) for _ in range(10)]


print (point)

theta = ag(1., 2., 3., 4.)
print ('theta')
print (theta)

N = 1000000
X = 68
Y = 285
cat = 0.


it = N
while it > 0:
    a, b = points( (0, 0) , (X, 0) , (0, Y) )
    theta = random.uniform(0, math.pi * 2)
    cat = cat + ag(a, b, X, Y) / (math.pi * 2)
    it = it - 1

print (cat / N)


#--------


y = [0.391591693975, 0.406055714897, 0.398653033136,
     0.418610344308,0.389720836982,0.412725302007, 0.428272468685998, 0.394963567348,
              0.43565432906, 0.423693379881, 0.396295811154, 0.3901474254,
              0.441641891524, 0.402436271833, 0.401163417645, 0.389987844273,
              0.432197023174, 0.393793616728, 0.446378794806, 0.409505617239,
              0.39031117093, 0.45047275832, 0.438858130925, 0.410650433193,
              0.394157221738, 0.389575071065, 0.415807631203, 0.453822339652,
              0.414789753678, 0.393180625879, 0.397244118174, 0.444115702732,
              0.403694364547, 0.390335057429, 0.456690054382, 0.390596492922,
              0.421418102949, 0.400182990631, 0.3968067066, 0.448546271813,
              0.459190836112, 0.408409471374, 0.42214620756, 0.403256296147,
              0.39276499847, 0.393423895298, 0.425994182644]
# y is the probability of the ant to go through refer to the anwer of line 39

mu = np.mean(y)
sigma = np.std(y)
mu, sigma = 0.021432249502251637, 0.4129772185196383
x = mu + sigma * np.random.randn(1000000)

# the histograof the data
num_bins = 47
n, bins, patches = plt.hist(x, 47 , normed=1, facecolor='green', alpha=0.75)

# add a 'best fit' line
y = mlab.normpdf( bins, mu, sigma)
l = plt.plot(bins, y, 'r--', linewidth=1)

plt.xlabel('The longest side')
plt.ylabel('Probability')
plt.title(r'$\mathrm{Histogram\ of\ Possibility:}\ \sigma=0.4129772185196383,\ \mu=0.021432249502251637$')
plt.axis([0, 35, 0, 0.5])
plt.grid(True)

plt.show()









































