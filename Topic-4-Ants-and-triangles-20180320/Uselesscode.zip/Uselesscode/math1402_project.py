import math
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import numpy as np
import random


def getdata(file):
    with open(file, 'r') as data:
        content = data.readlines()
        content = [x.strip() for x in content]

        datalist = []
        x1 = []
        for index in range(0, len(content)):
            test = [int(x) for x in content[index].split(' ')]
            datalist.append(test)
            x1.append(test[2])
        datalist = datalist

        
        return datalist

#Generate point
def generatePointsWithinTriangle(pt1, pt2, pt3):
    s, t = sorted([random.random(), random.random()])
    
    return (s * pt1[0] + (t-s)*pt2[0] + (1-t)*pt3[0],
            s * pt1[1] + (t-s)*pt2[1] + (1-t)*pt3[1])

def ag(x, y, a, b):
    return math.acos((x*(x-a) + y*(y-b))/(((x**2 + (y-b)**2)**(1./2.))*((x-a)**2 + y**2)**(1./2.)))

def custMax(lamba):
    cpr = lamba[0]
    flag = 0
    for index in range(0, 3):
        if cpr < lamba[index]:
            cpr = lamba[index]
            flag = index

    return flag

#q1
file = 'triangle_triples.data'
M = getdata(file)


#q2
data1 = M[0] #replace by index

p1 = (0, 0)
p2 = (data1[0], 0)
p3 = (0, data1[1])

point = generatePointsWithinTriangle(p1, p2, p3)
print(point)

line1 = math.hypot( point[0] - p1[0], point[1] - p1[1])
line2 = math.hypot( point[0] - p2[0], point[1] - p2[1])
line3 = math.hypot( point[0] - p3[0], point[1] - p3[1])

triangleCoord = []
triangleCoord.append(p1)
triangleCoord.append(p2)
triangleCoord.append(p3)
lamba = []
lamba.append(line1)
lamba.append(line2)
lamba.append(line3)

position = custMax(lamba)
requirePoint = triangleCoord[position]
print(requirePoint)

c1 = complex( requirePoint[0], requirePoint[1])
origin = complex(point[0], point[1] )
print(c1);
print(origin)

vector = c1 - origin
print(vector)
arg = np.angle(vector, deg=True)
print(arg)
